from flask import Blueprint, jsonify, render_template, request

from models.db import db, Registration
from services.email_service import send_email
from services.sms_service import send_sms

registration_bp = Blueprint("registration", __name__)


@registration_bp.route("/register", methods=["GET"])
def register_page():
    return render_template("registration.html")


@registration_bp.route("/api/register", methods=["POST"])
def register():
    data = request.get_json(silent=True) or request.form
    name = (data.get("full_name") or "").strip()
    email = (data.get("email") or "").strip()
    phone = (data.get("phone") or "").strip()

    if not name or not email or not phone:
        return jsonify(ok=False, error="Name, email and phone are required."), 400

    reg = Registration(
        full_name=name,
        email=email,
        phone=phone,
        education=data.get("education"),
        interest=data.get("interest"),
    )
    db.session.add(reg)
    db.session.commit()

    send_email(
        email,
        "Welcome to CareerNext",
        f"Hi {name},\n\nYour registration is confirmed. We'll be in touch soon.\n\n- Team CareerNext",
    )
    send_sms(phone, f"Hi {name}, your CareerNext registration is confirmed.")

    return jsonify(ok=True, message="Registration successful!")
