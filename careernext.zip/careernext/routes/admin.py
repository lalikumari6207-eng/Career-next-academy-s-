from flask import (Blueprint, current_app, jsonify, redirect, render_template,
                   request, session, url_for)

from models.db import Registration

admin_bp = Blueprint("admin", __name__, url_prefix="/admin")


@admin_bp.route("/", methods=["GET", "POST"])
def dashboard():
    if request.method == "POST":
        if request.form.get("password") == current_app.config["ADMIN_PASSWORD"]:
            session["admin"] = True
        return redirect(url_for("admin.dashboard"))

    if not session.get("admin"):
        return render_template("admin.html", authed=False, registrations=[])

    regs = Registration.query.order_by(Registration.created_at.desc()).all()
    return render_template("admin.html", authed=True, registrations=regs)


@admin_bp.route("/logout")
def logout():
    session.pop("admin", None)
    return redirect(url_for("admin.dashboard"))


@admin_bp.route("/api/registrations")
def api_registrations():
    if not session.get("admin"):
        return jsonify(error="Unauthorized"), 401
    regs = Registration.query.order_by(Registration.created_at.desc()).all()
    return jsonify([r.to_dict() for r in regs])
