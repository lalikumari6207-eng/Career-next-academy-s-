# =========================================================
# CareerNext Academy — Services
# =========================================================
import random
import smtplib
from datetime import datetime, timedelta
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from config import Config


# =========================================================
# EMAIL OTP helpers
# =========================================================
def generate_otp() -> str:
    return f"{random.randint(0, 999999):06d}"


def send_otp_email(to: str, otp: str, name: str = "Student") -> bool:
    subject = f"Your CareerNext Academy Verification Code: {otp}"
    html = f"""
    <div style="font-family:Arial,sans-serif;max-width:560px;margin:auto;
                border:1px solid #eee;border-radius:12px;padding:24px">
      <h2 style="color:#e0184f;margin:0 0 8px">CareerNext Academy</h2>
      <p>Hi <b>{name}</b>,</p>
      <p>Use the OTP below to verify your email and continue your registration:</p>
      <div style="background:#fdeaf0;color:#e0184f;font-family:'Courier New',monospace;
                  font-size:32px;font-weight:700;letter-spacing:8px;padding:16px;
                  border-radius:10px;text-align:center;margin:16px 0">
        {otp}
      </div>
      <p style="color:#888;font-size:13px">This code is valid for <b>10 minutes</b>.
         Do not share it with anyone.</p>
      <hr style="border:none;border-top:1px solid #eee;margin:20px 0">
      <p style="color:#aaa;font-size:12px">CareerNext Academy · Noida, Uttar Pradesh</p>
    </div>"""
    return send_email(to, subject, html)


# =========================================================
# EMAIL — SMTP
# =========================================================
def send_email(to: str, subject: str, html: str) -> bool:
    if not Config.SMTP_USER:
        print(f"[DEV EMAIL] → {to} | {subject}")
        return True
    try:
        msg = MIMEMultipart("alternative")
        msg["Subject"] = subject
        msg["From"] = Config.FROM_EMAIL
        msg["To"] = to
        msg.attach(MIMEText(html, "html"))
        with smtplib.SMTP_SSL(Config.SMTP_HOST, Config.SMTP_PORT) as s:
            s.login(Config.SMTP_USER, Config.SMTP_PASS)
            s.send_message(msg)
        return True
    except Exception as e:
        print("SMTP error:", e)
        return False


# =========================================================
# SHARED EMAIL HELPERS
# =========================================================
def _email_wrap(title: str, accent: str, body_html: str) -> str:
    """Common outer wrapper — dark header, white card body."""
    return f"""
<!DOCTYPE html>
<html>
<body style="margin:0;padding:0;background:#f4f4f7;
             font-family:-apple-system,Segoe UI,Roboto,Arial,sans-serif">
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0"
         style="background:#f4f4f7;padding:32px 12px">
    <tr><td align="center">
      <table role="presentation" width="600" cellpadding="0" cellspacing="0"
             style="max-width:600px;background:#ffffff;border-radius:14px;
                    overflow:hidden;box-shadow:0 6px 20px rgba(0,0,0,.06)">

        <!-- Header bar -->
        <tr><td style="background:linear-gradient(135deg,#e0184f,#8f0f38);
                       padding:24px 32px">
          <table width="100%" cellpadding="0" cellspacing="0">
            <tr>
              <td style="color:#ffffff;font-size:20px;font-weight:800;
                         letter-spacing:.3px">CareerNext Academy</td>
              <td align="right" style="color:rgba(255,255,255,.85);
                                       font-size:11px;letter-spacing:2px;
                                       font-weight:600">ACADEMY</td>
            </tr>
          </table>
        </td></tr>

        <!-- Title strip -->
        <tr><td style="background:{accent};padding:16px 32px;
                       color:#ffffff;font-size:15px;font-weight:700">
          {title}
        </td></tr>

        <!-- Body -->
        <tr><td style="padding:28px 32px">{body_html}</td></tr>

        <!-- Footer -->
        <tr><td style="background:#fafafa;padding:20px 32px;
                       border-top:1px solid #eee;
                       color:#888;font-size:12px;line-height:1.6">
          <b style="color:#333">CareerNext Academy</b><br>
          Kautilya Complex, Block B, Noida Phase-2, Noida, UP 201305<br>
          📞 +91 95463 33976 &nbsp;·&nbsp; ✉ info@careernextacademy.com
        </td></tr>

      </table>
    </td></tr>
  </table>
</body>
</html>"""


def _detail_row(label: str, value: str) -> str:
    return f"""
    <tr>
      <td style="padding:10px 14px;border-bottom:1px solid #eee;
                 color:#6b6470;font-size:13px;font-weight:600;
                 width:170px;vertical-align:top">{label}</td>
      <td style="padding:10px 14px;border-bottom:1px solid #eee;
                 color:#14121a;font-size:14px;font-weight:700;
                 vertical-align:top">{value}</td>
    </tr>"""


def _detail_table(rows: list) -> str:
    body = "".join(_detail_row(k, v) for k, v in rows)
    return f"""
    <table cellpadding="0" cellspacing="0" width="100%"
           style="border:1px solid #eee;border-radius:10px;overflow:hidden;
                  margin:8px 0 20px">
      {body}
    </table>"""


# =========================================================
# EMAIL TEMPLATES
# =========================================================
def student_email_html(name, reg_no, program=None, mode=None):
    """₹249 registration approved email (kept for backward-compat)."""
    prog = f"<p><b>Program:</b> {program}</p>" if program else ""
    plan = f"<p><b>Payment Plan:</b> {mode}</p>" if mode else ""
    return f"""
    <div style="font-family:Arial,sans-serif;max-width:560px;margin:auto;
                border:1px solid #eee;border-radius:12px;padding:24px">
      <h2 style="color:#e0184f;margin:0 0 8px">CareerNext Academy</h2>
      <p>Hi <b>{name}</b>,</p>
      <p>Your registration is confirmed 🎉</p>
      <p><b>Registration Number:</b>
         <span style="background:#fdeaf0;padding:6px 12px;border-radius:6px;
                      color:#e0184f;font-weight:700">{reg_no}</span></p>
      {prog}{plan}
      <p style="margin-top:16px">Our admissions team will WhatsApp/call you within
         24 hours with your batch schedule and document checklist.</p>
      <p style="color:#888;font-size:13px">Questions? Reply to this email or WhatsApp
         +91 95463 33976.</p>
    </div>"""


def payment_pending_email_html(name, reg_no, program, duration, amount, mode):
    """Sent when student submits program payment — awaiting admin verification."""
    body = f"""
      <p style="margin:0 0 8px;font-size:15px;color:#14121a">
        Hi <b>{name}</b>,
      </p>
      <p style="margin:0 0 18px;font-size:14px;color:#555;line-height:1.6">
        Thank you! We've successfully received your program payment details.
        Our team is verifying it now — this usually takes a few hours on business days.
      </p>

      {_detail_table([
        ("Registration No", reg_no),
        ("Student Name",    name),
        ("Program",         program),
        ("Duration",        duration),
        ("Payment Method",  mode),
        ("Amount Paid",     f"₹{amount:,}"),
        ("Status",          '<span style="color:#f5a524;font-weight:700">⏳ Payment Under Verification</span>'),
      ])}

      <div style="background:#fff8ec;border:1px solid #f5d9a5;border-radius:10px;
                  padding:14px 18px;color:#7a5a1e;font-size:13px;line-height:1.6">
        <b>What happens next?</b><br>
        Our admin team will verify your payment against the UTR you submitted.
        Once confirmed, you'll receive a <b>"Payment Successful"</b> email with
        your batch details.
      </div>

      <p style="margin:20px 0 0;font-size:13px;color:#888;line-height:1.6">
        If you have any questions, reply to this email or WhatsApp us at
        <b>+91 95463 33976</b>.
      </p>
    """
    return _email_wrap(
        title="⏳ Payment Under Verification",
        accent="#f5a524",
        body_html=body,
    )


def payment_success_email_html(name, reg_no, program, duration, amount, mode):
    """Sent when admin approves program payment — final confirmation."""
    body = f"""
      <p style="margin:0 0 8px;font-size:15px;color:#14121a">
        Hi <b>{name}</b>,
      </p>
      <p style="margin:0 0 18px;font-size:14px;color:#555;line-height:1.6">
        Great news! Your payment has been <b style="color:#22c55e">verified successfully</b> 🎉
        You are now officially enrolled in your program.
      </p>

      {_detail_table([
        ("Registration No", reg_no),
        ("Student Name",    name),
        ("Program",         program),
        ("Duration",        duration),
        ("Payment Method",  mode),
        ("Amount Paid",     f"₹{amount:,}"),
        ("Status",          '<span style="color:#22c55e;font-weight:700">✅ Payment Successful</span>'),
      ])}

      <div style="background:#f0fdf4;border:1px solid #86efac;border-radius:10px;
                  padding:14px 18px;color:#166534;font-size:13px;line-height:1.6">
        <b>You're all set!</b><br>
        Our admissions team will contact you within 24 hours with your batch
        schedule, class links, and document checklist.
      </div>

      <p style="margin:20px 0 0;font-size:13px;color:#888;line-height:1.6">
        Questions? Reply to this email or WhatsApp us at
        <b>+91 95463 33976</b>.
      </p>
    """
    return _email_wrap(
        title="✅ Payment Successful — You're Enrolled",
        accent="#22c55e",
        body_html=body,
    )


def admin_email_html(reg):
    rows = "".join(
        f"<tr><td style='padding:6px 10px;background:#fafafa'><b>{k}</b></td>"
        f"<td style='padding:6px 10px'>{v}</td></tr>"
        for k, v in reg.items()
    )
    return f"""
    <div style="font-family:Arial,sans-serif;max-width:640px;margin:auto">
      <h2 style="color:#e0184f">New Booking – CareerNext Academy</h2>
      <table style="border-collapse:collapse;width:100%;font-size:14px">{rows}</table>
    </div>"""