# =========================================================
# CareerNext Academy — Flask App
# OTP    : Email-based (MSG91 commented out)
# Payment: Manual UPI (QR + UTR + screenshot + admin approval)
# =========================================================
import os
import time
import random
from datetime import datetime, timedelta
from functools import wraps

from flask import (
    Flask, request, jsonify, render_template,
    session, redirect, url_for, abort,
)
from pymongo import MongoClient, DESCENDING
from bson import ObjectId
from bson.errors import InvalidId
from werkzeug.utils import secure_filename

from config import Config
from services import (
    generate_otp, send_otp_email,
    send_email, student_email_html,
    payment_pending_email_html, payment_success_email_html,
    admin_email_html,
)

app = Flask(__name__)
app.config.from_object(Config)
app.secret_key = Config.SECRET_KEY

# ---------- Uploads ----------
UPLOAD_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static", "uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)
ALLOWED_EXT = {"png", "jpg", "jpeg", "pdf", "webp"}
UPI_ID = "7004186219@ybl"
UPI_NAME = "CareerNext Academy"

def allowed_file(fn):
    return "." in fn and fn.rsplit(".", 1)[1].lower() in ALLOWED_EXT

# ---------- Mongo ----------
client = MongoClient(Config.MONGO_URI)
db = client[Config.MONGO_DB]
registrations = db.registrations
otp_store = db.otp_store
registrations.create_index("mobile", unique=True)
registrations.create_index("reg_number", unique=True, sparse=True)
otp_store.create_index("expires_at", expireAfterSeconds=0)

# ---------- Programs ----------
PROGRAMS = {
    "bandhan-assistant-manager":           ("Bandhan Bank Aspiring Bank Champions Programme — Assistant Manager", 335000, 4),
    "kotak-gold-loan":                     ("Kotak Gold Excellence Program — Gold Loan Relationship Officer", 215000, 3),
    "kotak-relationship-manager":          ("Kotak NextGen Bankers 2.0 Program — Relationship Manager", 385000, 5),
    "kotak-customer-service":              ("Kotak Accelerate Operations Programme — Customer Service Officer", 275000, 3),
    "mahindra-finance-business-executive": ("Mahindra Finance Prarambh Program — Business Executive", 215000, 3),
    "rbl-branch-manager":                  ("RBL Bank Branch Manager Leadership Program", 245000, 3),
    "dcb-bank-launchpad":                  ("DCB Bank Launchpad Program — Customer Service Manager", 215000, 3),
    "axis-retail-lending":                 ("Axis Bank Retail Lending Program — Assistant Manager", 385000, 5),
    "idfc-emerging-bankers":               ("IDFC FIRST Emerging Bankers Program", 385000, 5),
    "idfc-first-elevate":                  ("IDFC FIRST Bank Elevate Program — Associate Debt Manager", 275000, 3),
    "aviva-direct-sales":                  ("Aviva Nirmaan Program — Direct Sales Executive", 275000, 3),
    "piramal-relationship-manager":        ("Piramal ProEdge Program — Relationship Manager", 275000, 3),
    "hero-housing-relationship-manager":   ("Housing Finance Pragati Program — Relationship Manager", 215000, 3),
    "vedantu-academic-counsellor":         ("EdTech Launchpad Program — Academic Counsellor", 295000, 4),
    "aditya-birla-finishing-school":       ("Aditya Birla Capital Finishing School", 355000, 5),
    "hdfc-life-smart-achievers":           ("HDFC Life Smart Achievers Program — Sales Manager", 385000, 5),
    "finova-business-development":         ("Finova Capital Field Sales Program — BDE", 215000, 3),
    "house-of-founders-fellowship":        ("House of Founders Fellowship", 335000, 4),
    "leadership-excellence":               ("Leadership Excellence Program", 55000, 2),
    "team-leader-development":             ("Team Leader Development Program", 42000, 2),
    "communication-influence":             ("Communication & Influence Program", 42000, 2),
    "emotional-intelligence":              ("Emotional Intelligence Program", 42000, 2),
    "critical-thinking":                   ("Critical Thinking & Problem Solving Program", 55000, 2),
    "entrepreneurship-innovation":         ("Entrepreneurship & Innovation Program", 55000, 2),
}

# ---------- Program durations (matches your website) ----------
PROGRAM_DURATIONS = {
    # Banking & NBFC
    "idfc-emerging-bankers":               "1-Year Program",
    "idfc-first-elevate":                  "3-Month Program",
    "axis-retail-lending":                 "1-Year Program",
    "rbl-branch-manager":                  "2 Months Residential Training",
    "bandhan-assistant-manager":           "6-Month Program",
    "kotak-relationship-manager":          "1-Year Program",
    "kotak-gold-loan":                     "1-Month Program",
    "kotak-customer-service":              "3-Month Program",
    "mahindra-finance-business-executive": "1-Month Online Program",
    "dcb-bank-launchpad":                  "2-Week Training Program",

    # Insurance, Finance & Growth
    "hdfc-life-smart-achievers":           "1-Year Program",
    "aditya-birla-finishing-school":       "7-Month Program",
    "piramal-relationship-manager":        "3.5-Month Program",
    "aviva-direct-sales":                  "3-Month Program",
    "house-of-founders-fellowship":        "6-Month Hybrid Fellowship",
    "vedantu-academic-counsellor":         "4-Month Program",
    "hero-housing-relationship-manager":   "1-Month Program",
    "finova-business-development":         "15-Day Program",

    # Leadership & Skills
    "leadership-excellence":               "3 Months",
    "team-leader-development":             "2 Months",
    "communication-influence":             "2 Months",
    "emotional-intelligence":              "2 Months",
    "critical-thinking":                   "3 Months",
    "entrepreneurship-innovation":         "3 Months",
}


def gen_reg_no():
    return "CNA-" + str(datetime.utcnow().year) + "-" + str(random.randint(100000, 999999))


# =========================================================
# AUTH
# =========================================================
def admin_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if not session.get("admin_logged_in"):
            if request.path.startswith("/api/"):
                return jsonify(ok=False, error="Unauthorized"), 401
            return redirect(url_for("admin_page"))
        return f(*args, **kwargs)
    return wrapper


# =========================================================
# TEMPLATE HELPERS
# =========================================================
TEMPLATE_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "templates")
LEGACY_SKIP = {"Demo", "Demohtml", "index.html21", "index.htmlska", "Kalakq", "help-center.htmlkajkq"}


def template_exists(name):
    return os.path.isfile(os.path.join(TEMPLATE_DIR, f"{name}.html"))


def list_templates():
    if not os.path.isdir(TEMPLATE_DIR):
        return []
    return [fn[:-5] for fn in os.listdir(TEMPLATE_DIR)
            if fn.endswith(".html") and fn not in LEGACY_SKIP]


# =========================================================
# PAGES
# =========================================================
@app.route("/")
def home():
    return render_template("index.html")


@app.route("/<path:page>")
def serve_page(page):
    if page.startswith("api/"):
        abort(404)
    clean = page.strip("/")
    if clean.endswith(".html"):
        clean = clean[:-5]
    if ".." in clean or "/" in clean or "\\" in clean:
        abort(404)
    if clean in LEGACY_SKIP:
        abort(404)
    if template_exists(clean):
        return render_template(f"{clean}.html")
    abort(404)


@app.errorhandler(404)
def not_found(err):
    if request.path.startswith("/api/"):
        return jsonify(ok=False, error="Not found"), 404
    return "<h1 style='color:#e0184f;text-align:center;padding:60px'>404 — Page Not Found</h1><p style='text-align:center'><a href='/' style='color:#ff4d80'>Go Home</a></p>", 404


@app.errorhandler(500)
def server_error(err):
    if request.path.startswith("/api/"):
        return jsonify(ok=False, error="Internal server error"), 500
    return "<h1 style='color:#e0184f;text-align:center;padding:60px'>500 — Server Error</h1>", 500


# =========================================================
# ADMIN AUTH
# =========================================================
@app.route("/api/admin/login", methods=["POST"])
def api_admin_login():
    d = request.get_json(force=True)
    if (d.get("username", "").strip() == Config.ADMIN_USERNAME and
            d.get("password", "").strip() == Config.ADMIN_PASSWORD):
        session["admin_logged_in"] = True
        session["admin_user"] = d.get("username")
        return jsonify(ok=True)
    return jsonify(ok=False, error="Invalid credentials"), 401


@app.route("/api/admin/logout", methods=["POST"])
def api_admin_logout():
    session.clear()
    return jsonify(ok=True)


@app.route("/api/admin/me")
def api_admin_me():
    return jsonify(ok=True,
                   logged_in=bool(session.get("admin_logged_in")),
                   username=session.get("admin_user", ""))


# =========================================================
# STEP 1 : SAVE DETAILS
# =========================================================
@app.route("/api/register/details", methods=["POST"])
def api_details():
    d = request.get_json(force=True)
    required = ["full_name", "dob", "mobile", "email", "city", "state",
                "qualification", "stream", "passing_year", "marks"]
    missing = [f for f in required if not str(d.get(f, "")).strip()]
    if missing:
        return jsonify(ok=False, error=f"Missing: {', '.join(missing)}"), 400

    mobile = str(d["mobile"]).strip()
    if not (mobile.isdigit() and len(mobile) == 10):
        return jsonify(ok=False, error="Invalid mobile"), 400

    email = str(d["email"]).strip().lower()
    if "@" not in email:
        return jsonify(ok=False, error="Invalid email"), 400

    registrations.update_one(
        {"mobile": mobile},
        {"$set": {
            **{k: d.get(k) for k in required},
            "mobile": mobile,
            "email": email,
            "mobile_verified": False,
            "email_verified": False,
            "status": "details_submitted",
            "updated_at": datetime.utcnow(),
        },
         "$setOnInsert": {"created_at": datetime.utcnow()}},
        upsert=True)
    return jsonify(ok=True)


# =========================================================
# STEP 2 : SEND OTP (EMAIL)
# =========================================================
@app.route("/api/send-otp", methods=["POST"])
def api_send_otp():
    d = request.get_json(force=True)
    mobile = str(d.get("mobile", "")).strip()

    if not (mobile.isdigit() and len(mobile) == 10):
        return jsonify(ok=False, error="Invalid mobile"), 400

    reg = registrations.find_one({"mobile": mobile})
    if not reg:
        return jsonify(ok=False, error="Please complete the details form first"), 404

    email = reg.get("email", "").strip()
    if not email:
        return jsonify(ok=False, error="No email on record"), 400

    otp = generate_otp()
    expires_at = datetime.utcnow() + timedelta(minutes=10)

    otp_store.update_one(
        {"mobile": mobile},
        {"$set": {
            "mobile": mobile,
            "otp": otp,
            "expires_at": expires_at,
            "sent_at": datetime.utcnow(),
            "attempts": 0,
        }},
        upsert=True)

    ok = send_otp_email(email, otp, reg.get("full_name", "Student"))
    if not ok:
        return jsonify(ok=False, error="Could not send OTP email"), 502

    parts = email.split("@")
    masked = parts[0][:2] + "*" * max(1, len(parts[0]) - 2) + "@" + parts[1]

    return jsonify(ok=True, email_masked=masked, message="OTP sent to your email")


# =========================================================
# STEP 2b : VERIFY OTP (EMAIL)
# =========================================================
@app.route("/api/verify-otp", methods=["POST"])
def api_verify_otp():
    d = request.get_json(force=True)
    mobile = str(d.get("mobile", "")).strip()
    otp = str(d.get("otp", "")).strip()

    if not (mobile and otp and len(otp) == 6):
        return jsonify(ok=False, error="Enter the 6-digit code"), 400

    rec = otp_store.find_one({"mobile": mobile})
    if not rec:
        return jsonify(ok=False, error="No OTP found. Click Resend."), 400

    if rec.get("expires_at") and rec["expires_at"] < datetime.utcnow():
        otp_store.delete_one({"mobile": mobile})
        return jsonify(ok=False, error="OTP expired. Click Resend."), 400

    if rec.get("attempts", 0) >= 5:
        return jsonify(ok=False, error="Too many wrong attempts. Click Resend."), 429

    if rec.get("otp") != otp:
        otp_store.update_one({"mobile": mobile}, {"$inc": {"attempts": 1}})
        return jsonify(ok=False, error="Incorrect code. Try again."), 400

    registrations.update_one(
        {"mobile": mobile},
        {"$set": {
            "mobile_verified": True,
            "email_verified": True,
            "status": "mobile_verified",
            "updated_at": datetime.utcnow(),
        }})
    otp_store.delete_one({"mobile": mobile})

    return jsonify(ok=True, message="Verified")


# =========================================================
# (MSG91 endpoint — disabled)
# =========================================================
@app.route("/api/verify-msg91", methods=["POST"])
def api_verify_msg91():
    return jsonify(ok=False, error="MSG91 verification is disabled. Use email OTP."), 400


# =========================================================
# STEP 3 : ₹249 PAYMENT
# =========================================================
@app.route("/api/pay-registration", methods=["POST"])
def api_pay_registration():
    mobile = request.form.get("mobile", "").strip()
    utr = request.form.get("utr", "").strip()
    screenshot = request.files.get("screenshot")

    if not (mobile.isdigit() and len(mobile) == 10):
        return jsonify(ok=False, error="Invalid mobile number"), 400
    if not utr or not utr.isdigit() or not (8 <= len(utr) <= 12):
        return jsonify(ok=False, error="Enter valid UTR (8–12 digits)"), 400

    reg = registrations.find_one({"mobile": mobile})
    if not reg:
        return jsonify(ok=False, error="Registration not found. Please redo step 1."), 404
    if not reg.get("mobile_verified"):
        return jsonify(ok=False, error="Verify your email OTP first"), 400
    if reg.get("reg_utr") and reg["reg_utr"] != utr:
        return jsonify(ok=False, error="₹249 already submitted"), 400

    dup = registrations.find_one({"reg_utr": utr, "mobile": {"$ne": mobile}})
    if dup:
        return jsonify(ok=False, error="This UTR is already used"), 400

    screenshot_path = ""
    if screenshot and screenshot.filename:
        if not allowed_file(screenshot.filename):
            return jsonify(ok=False, error="Only png/jpg/jpeg/webp/pdf allowed"), 400
        safe = secure_filename(screenshot.filename)
        fname = f"reg_{mobile}_{int(time.time())}_{safe}"
        screenshot.save(os.path.join(UPLOAD_DIR, fname))
        screenshot_path = f"/static/uploads/{fname}"

    reg_no = reg.get("reg_number") or gen_reg_no()

    registrations.update_one(
        {"mobile": mobile},
        {"$set": {
            "reg_number": reg_no,
            "reg_utr": utr,
            "reg_screenshot": screenshot_path,
            "reg_amount": Config.REG_FEE,
            "registration_paid": False,
            "reg_status": "pending",
            "reg_submitted_at": datetime.utcnow(),
            "status": "reg_payment_pending",
            "updated_at": datetime.utcnow(),
        }})

    send_email(
        Config.ADMIN_EMAIL,
        f"₹249 Payment Pending — {reg['full_name']} ({mobile})",
        admin_email_html({
            "Type": "₹249 Registration Fee",
            "Reg No": reg_no,
            "Name": reg["full_name"],
            "Mobile": mobile,
            "Email": reg["email"],
            "UTR": utr,
            "Screenshot": screenshot_path or "Not uploaded",
            "Amount": f"₹{Config.REG_FEE}",
            "Time": datetime.utcnow().strftime("%d-%b-%Y %H:%M UTC"),
        }))

    return jsonify(ok=True, reg_number=reg_no,
                   message="Payment submitted. Awaiting verification.")


# =========================================================
# STEP 4/5 : PROGRAM ENROLL — sends "payment pending" email with duration
# =========================================================
@app.route("/api/enroll", methods=["POST"])
def api_enroll():
    reg_no = request.form.get("reg_number", "").strip()
    program_key = request.form.get("program", "").strip()
    mode = request.form.get("mode", "full")
    utr = request.form.get("utr", "").strip()
    screenshot = request.files.get("screenshot")

    reg = registrations.find_one({"reg_number": reg_no})
    if not reg:
        return jsonify(ok=False, error="Invalid registration number"), 404
    if program_key not in PROGRAMS:
        return jsonify(ok=False, error="Invalid program"), 400
    if not utr or not utr.isdigit() or not (8 <= len(utr) <= 12):
        return jsonify(ok=False, error="Enter valid UTR (8–12 digits)"), 400

    dup = registrations.find_one({"program_utr": utr, "reg_number": {"$ne": reg_no}})
    if dup:
        return jsonify(ok=False, error="This UTR is already used"), 400

    name, fee, inst_count = PROGRAMS[program_key]
    duration = PROGRAM_DURATIONS.get(program_key, "—")
    per_inst = round(fee / inst_count / 100) * 100
    amount_due = (fee - Config.REG_FEE) if mode == "full" else per_inst

    screenshot_path = ""
    if screenshot and screenshot.filename:
        if not allowed_file(screenshot.filename):
            return jsonify(ok=False, error="Only png/jpg/jpeg/webp/pdf allowed"), 400
        safe = secure_filename(screenshot.filename)
        fname = f"enr_{reg_no}_{int(time.time())}_{safe}"
        screenshot.save(os.path.join(UPLOAD_DIR, fname))
        screenshot_path = f"/static/uploads/{fname}"

    registrations.update_one(
        {"reg_number": reg_no},
        {"$set": {
            "program_key": program_key,
            "program_name": name,
            "program_duration": duration,
            "program_fee": fee,
            "payment_mode": mode,
            "installments": inst_count if mode == "installment" else 1,
            "amount_due": amount_due,
            "program_utr": utr,
            "program_screenshot": screenshot_path,
            "program_paid": False,
            "program_status": "pending",
            "program_submitted_at": datetime.utcnow(),
            "status": "program_payment_pending",
            "updated_at": datetime.utcnow(),
        }})

    mode_label = "Full Payment" if mode == "full" else f"{inst_count} Installments"

    # ✅ Student: "Payment Under Verification" with full details
    send_email(
        reg["email"],
        f"Payment Under Verification — {name}",
        payment_pending_email_html(
            reg["full_name"], reg_no, name, duration, amount_due, mode_label))

    # Admin notification
    send_email(
        Config.ADMIN_EMAIL,
        f"Program Payment Pending — {reg['full_name']} → {name}",
        admin_email_html({
            "Type": "Program Enrollment",
            "Reg No": reg_no,
            "Student": reg["full_name"],
            "Mobile": reg["mobile"],
            "Email": reg["email"],
            "Program": name,
            "Duration": duration,
            "Plan": mode_label,
            "Amount Paid Now": f"₹{amount_due:,}",
            "UTR": utr,
            "Screenshot": screenshot_path or "Not uploaded",
            "Time": datetime.utcnow().strftime("%d-%b-%Y %H:%M UTC"),
        }))

    return jsonify(ok=True, program_name=name, amount_due=amount_due,
                   message="Payment submitted. Awaiting verification.")


# =========================================================
# ADMIN : APPROVE / REJECT ₹249
# =========================================================
@app.route("/api/admin/approve-reg", methods=["POST"])
@admin_required
def api_admin_approve_reg():
    d = request.get_json(force=True)
    mobile = str(d.get("mobile", "")).strip()
    reg = registrations.find_one({"mobile": mobile})
    if not reg:
        return jsonify(ok=False, error="Not found"), 404
    if reg.get("registration_paid"):
        return jsonify(ok=False, error="Already approved"), 400

    reg_no = reg.get("reg_number") or gen_reg_no()

    registrations.update_one(
        {"mobile": mobile},
        {"$set": {
            "reg_number": reg_no,
            "registration_paid": True,
            "reg_status": "approved",
            "registration_paid_at": datetime.utcnow(),
            "status": "registered",
            "updated_at": datetime.utcnow(),
        }})

    send_email(reg["email"], f"₹249 Payment Verified — {reg_no}",
               student_email_html(reg["full_name"], reg_no))
    return jsonify(ok=True, reg_number=reg_no)


@app.route("/api/admin/reject-reg", methods=["POST"])
@admin_required
def api_admin_reject_reg():
    d = request.get_json(force=True)
    mobile = str(d.get("mobile", "")).strip()
    reason = str(d.get("reason", "")).strip() or "Payment could not be verified."
    reg = registrations.find_one({"mobile": mobile})
    if not reg:
        return jsonify(ok=False, error="Not found"), 404

    registrations.update_one(
        {"mobile": mobile},
        {"$set": {
            "reg_status": "rejected",
            "reg_reject_reason": reason,
            "status": "mobile_verified",
            "updated_at": datetime.utcnow(),
        }})

    send_email(reg["email"], "Registration payment not verified",
        f"""<div style="font-family:Arial;padding:24px">
        <h2 style="color:#e0184f">CareerNext Academy</h2>
        <p>Hi <b>{reg['full_name']}</b>,</p>
        <p>Your ₹249 payment could not be verified.</p>
        <p><b>Reason:</b> {reason}</p></div>""")
    return jsonify(ok=True)


# =========================================================
# ADMIN : APPROVE / REJECT PROGRAM — sends "payment successful" email
# =========================================================
@app.route("/api/admin/approve-program", methods=["POST"])
@admin_required
def api_admin_approve_program():
    d = request.get_json(force=True)
    reg_no = str(d.get("reg_number", "")).strip()
    reg = registrations.find_one({"reg_number": reg_no})
    if not reg:
        return jsonify(ok=False, error="Not found"), 404
    if reg.get("program_paid"):
        return jsonify(ok=False, error="Already approved"), 400

    registrations.update_one(
        {"reg_number": reg_no},
        {"$set": {
            "program_paid": True,
            "program_status": "approved",
            "program_paid_at": datetime.utcnow(),
            "status": "enrolled",
            "enrolled_at": datetime.utcnow(),
            "updated_at": datetime.utcnow(),
        }})

    program_name = reg.get("program_name", "Your Program")
    duration = reg.get("program_duration") or PROGRAM_DURATIONS.get(reg.get("program_key", ""), "—")
    amount = reg.get("amount_due", 0)
    mode = reg.get("payment_mode", "full")
    inst = reg.get("installments", 1)
    mode_label = "Full Payment" if mode == "full" else f"{inst} Installments"

    # ✅ Student: "Payment Successful" with all details
    send_email(
        reg["email"],
        f"Payment Successful — {program_name}",
        payment_success_email_html(
            reg["full_name"], reg_no, program_name, duration, amount, mode_label))

    return jsonify(ok=True)


@app.route("/api/admin/reject-program", methods=["POST"])
@admin_required
def api_admin_reject_program():
    d = request.get_json(force=True)
    reg_no = str(d.get("reg_number", "")).strip()
    reason = str(d.get("reason", "")).strip() or "Payment could not be verified."
    reg = registrations.find_one({"reg_number": reg_no})
    if not reg:
        return jsonify(ok=False, error="Not found"), 404

    registrations.update_one(
        {"reg_number": reg_no},
        {"$set": {
            "program_status": "rejected",
            "program_reject_reason": reason,
            "status": "registered",
            "updated_at": datetime.utcnow(),
        }})

    send_email(reg["email"], "Program payment not verified",
        f"""<div style="font-family:Arial;padding:24px">
        <h2 style="color:#e0184f">CareerNext Academy</h2>
        <p>Hi <b>{reg['full_name']}</b>,</p>
        <p>Your program payment could not be verified.</p>
        <p><b>Reason:</b> {reason}</p>
        <p>Please re-submit with correct UTR/screenshot.</p></div>""")
    return jsonify(ok=True)


# =========================================================
# ADMIN LIST / STATS / DELETE
# =========================================================
@app.route("/api/admin/registrations")
@admin_required
def api_admin_list():
    docs = list(registrations.find().sort("created_at", DESCENDING))
    for x in docs:
        x["_id"] = str(x["_id"])
        for k, v in list(x.items()):
            if isinstance(v, datetime):
                x[k] = v.isoformat()
    return jsonify(ok=True, data=docs)


@app.route("/api/admin/stats")
@admin_required
def api_admin_stats():
    total      = registrations.count_documents({})
    registered = registrations.count_documents({"status": "registered"})
    enrolled   = registrations.count_documents({"status": "enrolled"})
    pending    = registrations.count_documents(
        {"$or": [{"reg_status": "pending"}, {"program_status": "pending"}]})
    verified   = registrations.count_documents({"mobile_verified": True})
    return jsonify(ok=True, stats={
        "total": total, "registered": registered,
        "enrolled": enrolled, "pending": pending, "verified": verified})


@app.route("/api/admin/registration/<reg_id>", methods=["DELETE"])
@admin_required
def api_admin_delete(reg_id):
    try:
        oid = ObjectId(reg_id)
    except (InvalidId, TypeError):
        return jsonify(ok=False, error="Invalid id"), 400
    res = registrations.delete_one({"_id": oid})
    if res.deleted_count == 0:
        return jsonify(ok=False, error="Not found"), 404
    return jsonify(ok=True)


# =========================================================
# RUN
# =========================================================
if __name__ == "__main__":
    print("\n📄 Available templates:")
    for t in sorted(list_templates()):
        print(f"   /{t}")
    print("\n📧 OTP is EMAIL-based (MSG91 disabled)\n")
    app.run(debug=True, port=5000, use_reloader=False)