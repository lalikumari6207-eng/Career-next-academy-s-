/* ============================================================
   CareerNext Academy — Registration Wizard
   OTP via Email
   ============================================================ */
(function () {
  const wiz = document.getElementById('regWizard');
  if (!wiz) return;

  const steps = ['s1','s2','s3','s4','s5'];
  let current = 0;
  let mobile = localStorage.getItem('cna_mobile') || '';

  const UPI_ID = "7004186219@ybl";
  const UPI_NAME = "CareerNext Academy";

  function upiUrl(amt, note) {
    const p = new URLSearchParams({ pa: UPI_ID, pn: UPI_NAME, am: String(amt), cu: "INR", tn: note || "Payment" });
    return "upi://pay?" + p.toString();
  }
  function qrUrl(amt, note) {
    return "https://api.qrserver.com/v1/create-qr-code/?size=220x220&margin=8&data="
      + encodeURIComponent(upiUrl(amt, note));
  }

  async function api(path, body) {
    try {
      const r = await fetch(path, { method:'POST',
        headers:{'Content-Type':'application/json'},
        body: JSON.stringify(body || {}) });
      return await r.json();
    } catch (e) {
      console.error('API error:', path, e);
      return { ok:false, error:'Network error' };
    }
  }

  function showStep(i) {
    steps.forEach((id, idx) => {
      const el = document.getElementById(id);
      if (el) el.style.display = (idx === i) ? '' : 'none';
    });
    document.querySelectorAll('.steps-bar .step').forEach((el, idx) => {
      el.classList.toggle('active', idx === i);
      el.classList.toggle('done', idx < i);
    });
    window.scrollTo({ top: wiz.offsetTop - 90, behavior: 'smooth' });
    current = i;

    if (i === 3) {
      const inp = document.getElementById('enrollRegNo');
      const saved = localStorage.getItem('cna_reg_number');
      if (inp && saved) inp.value = saved;
      const disp = document.getElementById('regNoDisplay');
      if (disp && saved) disp.textContent = saved;
    }
    if (i === 4 && typeof refreshEnrollPaymentUI === 'function') refreshEnrollPaymentUI();
  }

  document.querySelectorAll(".copy-btn").forEach(b => {
    b.addEventListener("click", async () => {
      try {
        await navigator.clipboard.writeText(b.dataset.copy);
        const t = b.textContent; b.textContent = "Copied!";
        setTimeout(()=>b.textContent=t, 1200);
      } catch(e){}
    });
  });

  /* ============== STEP 1 — save + send email OTP ============== */
  const form1 = document.getElementById('detailsForm');
  form1.addEventListener('submit', async function (ev) {
    ev.preventDefault();
    let valid = true;
    form1.querySelectorAll('[required]').forEach(inp => {
      const grp = inp.closest('.f-group');
      if (!inp.value.trim()) { grp.classList.add('invalid'); valid = false; }
      else grp.classList.remove('invalid');
    });
    if (!valid) return;

    const data = Object.fromEntries(new FormData(form1).entries());
    mobile = data.mobile.trim();
    localStorage.setItem('cna_mobile', mobile);

    const btn = document.getElementById('detailsSubmitBtn');
    const orig = btn.innerHTML;
    btn.disabled = true; btn.textContent = 'Saving…';

    const saveRes = await api('/api/register/details', data);
    if (!saveRes.ok) {
      btn.disabled = false; btn.innerHTML = orig;
      alert(saveRes.error || 'Save failed');
      return;
    }

    btn.textContent = 'Sending OTP to email…';
    const otpRes = await api('/api/send-otp', { mobile });
    btn.disabled = false; btn.innerHTML = orig;
    if (!otpRes.ok) {
      alert(otpRes.error || 'Could not send OTP');
      return;
    }

    document.getElementById('otpEmailDisplay').textContent =
      otpRes.email_masked || data.email;
    showStep(1);
  });

  /* ============== STEP 2 — verify email OTP ============== */
  const otpInputs = document.querySelectorAll('.otp-inputs input');
  otpInputs.forEach((inp, i) => {
    inp.addEventListener('input', () => {
      inp.value = inp.value.replace(/[^0-9]/g,'').slice(0,1);
      if (inp.value && otpInputs[i+1]) otpInputs[i+1].focus();
    });
    inp.addEventListener('keydown', e => {
      if (e.key === 'Backspace' && !inp.value && otpInputs[i-1]) otpInputs[i-1].focus();
    });
  });

  document.getElementById('verifyOtpBtn').addEventListener('click', async function () {
    const code = Array.from(otpInputs).map(i=>i.value).join('');
    const msg = document.getElementById('otpMsg');
    const btn = this;

    if (code.length < 6) {
      msg.textContent = 'Enter the 6-digit code';
      msg.className = 'otp-msg err';
      otpInputs.forEach(i=>i.classList.add('err'));
      return;
    }

    btn.disabled = true; btn.textContent = 'Verifying…';
    const res = await api('/api/verify-otp', { mobile, otp: code });
    btn.disabled = false; btn.textContent = 'Verify & Continue';

    if (!res.ok) {
      msg.textContent = res.error || 'Invalid code';
      msg.className = 'otp-msg err';
      otpInputs.forEach(i=>i.classList.add('err'));
      return;
    }

    otpInputs.forEach(i=>i.classList.remove('err'));
    msg.textContent = 'Verified ✅';
    msg.className = 'otp-msg ok';
    setTimeout(()=>showStep(2), 500);
  });

  document.getElementById('resendOtp').addEventListener('click', async function(e){
    e.preventDefault();
    const msg = document.getElementById('otpMsg');
    msg.textContent = 'Sending…'; msg.className = 'otp-msg';
    const res = await api('/api/send-otp', { mobile });
    if (res.ok) {
      msg.textContent = 'Fresh code sent to ' + (res.email_masked || 'your email');
      msg.className = 'otp-msg ok';
    } else {
      msg.textContent = res.error || 'Could not resend';
      msg.className = 'otp-msg err';
    }
  });

  /* ============== STEP 3 — ₹249 ============== */
  document.getElementById("regQr").src = qrUrl(249, "CareerNext Registration Fee");
  document.getElementById("regUpiLink").href = upiUrl(249, "CareerNext Registration Fee");

  document.getElementById("regScreenshot").addEventListener("change", function(){
    const f = this.files[0];
    const box = document.getElementById("regUploadBox");
    const name = document.getElementById("regFileName");
    if (f){ box.classList.add("filled"); name.textContent = f.name; }
    else { box.classList.remove("filled"); name.textContent = ""; }
  });

  document.getElementById('payRegFeeBtn').addEventListener('click', async function () {
    const utr = document.getElementById("regUtr").value.trim();
    const file = document.getElementById("regScreenshot").files[0];

    if (!/^\d{8,12}$/.test(utr)) { alert("Enter valid UTR (8–12 digits)"); return; }
    if (!mobile) { alert("Session lost. Refresh and start again."); return; }

    const btn = this;
    btn.textContent = 'Submitting…'; btn.disabled = true;

    const fd = new FormData();
    fd.append("mobile", mobile);
    fd.append("utr", utr);
    if (file) fd.append("screenshot", file);

    let res;
    try {
      const r = await fetch("/api/pay-registration", { method:"POST", body: fd });
      res = await r.json();
    } catch (e) {
      btn.textContent = 'Submit Payment for Verification';
      btn.disabled = false;
      alert("Network error. Try again."); return;
    }

    btn.textContent = 'Submit Payment for Verification';
    btn.disabled = false;

    if (!res.ok) { alert(res.error || "Submission failed"); return; }

    if (res.reg_number) {
      localStorage.setItem('cna_reg_number', res.reg_number);
      document.getElementById('regNoDisplay').textContent = res.reg_number;
      document.getElementById('enrollRegNo').value = res.reg_number;
    }
    showStep(3);
  });

  /* ============== STEP 4 — program ============== */
  const enrollRegInput = document.getElementById('enrollRegNo');
  const progSelect = document.getElementById('progSelect');
  const feeBox = document.getElementById('enrollFeeBox');
  const payOptsWrap = document.getElementById('payOptsWrap');

  const savedReg = localStorage.getItem('cna_reg_number');
  if (savedReg) enrollRegInput.value = savedReg;

  const pre = new URLSearchParams(location.search).get('program');
  if (pre) {
    const opt = progSelect.querySelector('option[value="'+pre+'"]');
    if (opt) progSelect.value = pre;
  }

  let selectedFee = 0, selectedInst = 3, selectedMode = 'full';

  function renderFee() {
    const opt = progSelect.selectedOptions[0];
    if (!opt || !opt.dataset.fee) { feeBox.innerHTML=''; payOptsWrap.innerHTML=''; return; }
    selectedFee = parseInt(opt.dataset.fee, 10);
    selectedInst = parseInt(opt.dataset.inst, 10);
    feeBox.innerHTML = '<div><b>₹' + selectedFee.toLocaleString('en-IN') +
      '</b><span>Total program fee</span></div><span>' + opt.dataset.name + '</span>';
    const perInst = Math.round(selectedFee / selectedInst / 100) * 100;
    payOptsWrap.innerHTML = `
      <div class="pay-opt sel" data-mode="full">
        <div class="pay-opt-left"><input type="radio" name="payMode" checked>
          <div><b>Pay Full Amount</b><span>One-time, reg fee adjusted</span></div></div>
        <div class="amt">₹${(selectedFee-249).toLocaleString('en-IN')}</div>
      </div>
      <div class="pay-opt" data-mode="installment">
        <div class="pay-opt-left"><input type="radio" name="payMode">
          <div><b>Pay in Installments</b><span>${selectedInst} x ₹${perInst.toLocaleString('en-IN')}</span></div></div>
        <div class="amt">₹${perInst.toLocaleString('en-IN')} first</div>
      </div>`;
    payOptsWrap.querySelectorAll('.pay-opt').forEach(el => {
      el.addEventListener('click', () => {
        payOptsWrap.querySelectorAll('.pay-opt').forEach(x => {
          x.classList.remove('sel'); x.querySelector('input').checked = false;
        });
        el.classList.add('sel'); el.querySelector('input').checked = true;
        selectedMode = el.dataset.mode;
        refreshEnrollPaymentUI();
      });
    });
    selectedMode = "full";
    refreshEnrollPaymentUI();
  }

  progSelect.addEventListener('change', renderFee);
  if (progSelect.value) renderFee();

  document.getElementById('goEnrollStep').addEventListener('click', () => {
    if (!enrollRegInput.value.trim()) {
      enrollRegInput.closest('.f-group').classList.add('invalid');
      alert("Registration number missing. Please complete ₹249 step.");
      return;
    }
    if (!progSelect.value) {
      progSelect.closest('.f-group').classList.add('invalid');
      alert("Please select a program."); return;
    }
    renderFee();
    showStep(4);
  });

  /* ============== STEP 5 — program pay ============== */
  function refreshEnrollPaymentUI() {
    const amt = (selectedMode === "full")
      ? (selectedFee - 249)
      : Math.round(selectedFee / selectedInst / 100) * 100;
    document.getElementById("enrollAmt").textContent = "₹" + amt.toLocaleString("en-IN");
    document.getElementById("enrollQr").src = qrUrl(amt, "Program Fee");
    document.getElementById("enrollUpiLink").href = upiUrl(amt, "Program Fee");
  }

  document.getElementById("enrollScreenshot").addEventListener("change", function(){
    const f = this.files[0];
    const box = document.getElementById("enrollUploadBox");
    const name = document.getElementById("enrollFileName");
    if (f){ box.classList.add("filled"); name.textContent = f.name; }
    else { box.classList.remove("filled"); name.textContent = ""; }
  });

  document.getElementById('finalPayBtn').addEventListener('click', async function () {
    const utr = document.getElementById("enrollUtr").value.trim();
    const file = document.getElementById("enrollScreenshot").files[0];
    if (!/^\d{8,12}$/.test(utr)) { alert("Enter valid UTR (8–12 digits)"); return; }

    const btn = this;
    btn.textContent = 'Submitting…'; btn.disabled = true;

    const fd = new FormData();
    fd.append("reg_number", enrollRegInput.value.trim());
    fd.append("program", progSelect.value);
    fd.append("mode", selectedMode);
    fd.append("utr", utr);
    if (file) fd.append("screenshot", file);

    let res;
    try {
      const r = await fetch("/api/enroll", { method:"POST", body: fd });
      res = await r.json();
    } catch (e) {
      btn.textContent = 'Submit Payment for Verification';
      btn.disabled = false;
      alert("Network error. Try again."); return;
    }

    btn.textContent = 'Submit Payment for Verification';
    btn.disabled = false;

    if (!res.ok) { alert(res.error || "Submission failed"); return; }

    document.getElementById("finalProgramName").textContent = res.program_name;
    document.getElementById("finalRegNo").textContent = enrollRegInput.value.trim();
    document.getElementById("finalMode").textContent =
      selectedMode === 'full' ? 'Full Payment' : (selectedInst + ' Installments');

    wiz.querySelectorAll('.wizard-card').forEach(c => {
      if (c.id !== 'enrollSuccessCard') c.style.display = 'none';
    });
    document.getElementById('enrollSuccessCard').style.display = '';
    document.querySelectorAll('.steps-bar .step').forEach(el => el.classList.add('done'));
  });

  document.querySelectorAll('.wiz-back').forEach(btn => {
    btn.addEventListener('click', () => showStep(Math.max(0, current-1)));
  });

})();