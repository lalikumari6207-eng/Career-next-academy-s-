/* ============================================================
   CareerNext Academy — shared interactions
   ============================================================ */
const WA_NUMBER = "919546333976";

function waLink(message){
  return `https://wa.me/${WA_NUMBER}?text=${encodeURIComponent(message)}`;
}

document.addEventListener("DOMContentLoaded", () => {

  /* ---------- page-load animation ---------- */
  document.body.classList.add("loading");
  const loader = document.getElementById("pageLoader");
  setTimeout(() => {
    if (loader) loader.classList.add("hide");
    document.body.classList.remove("loading");
  }, 250);

  /* ---------- mobile nav ---------- */
  const burger = document.querySelector(".burger");
  const navlinks = document.querySelector(".navlinks");
  if (burger && navlinks) {
    burger.addEventListener("click", () => navlinks.classList.toggle("open"));
    navlinks.querySelectorAll("a").forEach(a =>
      a.addEventListener("click", () => navlinks.classList.remove("open")));
  }

  /* ---------- reveal-on-scroll ---------- */
  const io = new IntersectionObserver((entries) => {
    entries.forEach(e => {
      if (e.isIntersecting) { e.target.classList.add("in"); io.unobserve(e.target); }
    });
  }, { threshold: .18 });

  document.querySelectorAll(".pcard, .why-item, .tl-item, .highlight-list li, .eligi-card, .reveal")
    .forEach((el, i) => {
      el.style.setProperty("--d", (i % 6) * 0.09 + "s");
      io.observe(el);
    });

  /* ---------- timeline progress ---------- */
  const timeline = document.querySelector(".timeline");
  if (timeline) {
    const tlIO = new IntersectionObserver((entries) => {
      entries.forEach(e => {
        if (e.isIntersecting) { timeline.style.setProperty("--p", "100%"); tlIO.unobserve(e.target); }
      });
    }, { threshold: .3 });
    tlIO.observe(timeline);
  }

  /* ---------- animated counters ---------- */
  const counters = document.querySelectorAll("[data-count]");
  const cIO = new IntersectionObserver((entries) => {
    entries.forEach(e => {
      if (!e.isIntersecting) return;
      const el = e.target;
      const target = parseFloat(el.dataset.count);
      const suffix = el.dataset.suffix || "";
      const dur = 1400;
      const start = performance.now();
      function tick(now) {
        const p = Math.min(1, (now - start) / dur);
        const eased = 1 - Math.pow(1 - p, 3);
        const val = Math.round(target * eased * 10) / 10;
        el.textContent = (Number.isInteger(target) ? Math.round(target * eased) : val.toFixed(1)) + suffix;
        if (p < 1) requestAnimationFrame(tick);
      }
      requestAnimationFrame(tick);
      cIO.unobserve(el);
    });
  }, { threshold: .6 });
  counters.forEach(el => cIO.observe(el));

  /* ---------- FAQ accordion ---------- */
  document.querySelectorAll(".faq-item button").forEach(btn => {
    btn.addEventListener("click", () => {
      const item = btn.closest(".faq-item");
      const wasOpen = item.classList.contains("open");
      item.parentElement.querySelectorAll(".faq-item").forEach(f => f.classList.remove("open"));
      if (!wasOpen) item.classList.add("open");
    });
  });

  /* ---------- WhatsApp links ---------- */
  document.querySelectorAll(".js-wa, .wa-float, #enquireBtn, #talkExpertBtn").forEach(el => {
    const msg = el.dataset.msg || "Hi CareerNext Academy, I'd like to know more about your programs.";
    el.href = waLink(msg);
    el.target = "_blank";
    el.rel = "noopener";
  });

  /* ---------- Apply form (program pages) ---------- */
  const applyForm = document.getElementById("applyForm");
  if (applyForm) {
    applyForm.addEventListener("submit", (ev) => {
      ev.preventDefault();
      const name = applyForm.querySelector("[name=full_name]").value.trim();
      const city = applyForm.querySelector("[name=city]").value.trim();
      const programName = applyForm.dataset.program || "your program";
      const msg = `Hi CareerNext Academy, I'm ${name || "interested"} from ${city || "my city"}. I want to apply for the ${programName}. Please share the next steps.`;
      window.open(waLink(msg), "_blank");
    });
  }
});