import os
from dotenv import load_dotenv

load_dotenv()


UPLOAD_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static", "uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)
ALLOWED_EXT = {"png", "jpg", "jpeg", "pdf", "webp"}
UPI_ID = "7004186219@ybl"
UPI_NAME = "CareerNext Academy"


def allowed_file(fn):
    return "." in fn and fn.rsplit(".", 1)[1].lower() in ALLOWED_EXT

class Config:
    SECRET_KEY = os.getenv("SECRET_KEY", "dev-secret")
    MONGO_URI = os.getenv("MONGO_URI", "mongodb+srv://gau879731raj_db_user:qLDy7yu9CTQuMl9J@cluster06.nxm5det.mongodb.net/?appName=Cluster06&compressors=zlib")
    MONGO_DB = os.getenv("MONGO_DB", "careernext")

    # Twilio Verify
    # TWILIO_ACCOUNT_SID = os.getenv("TWILIO_ACCOUNT_SID", "")
    # TWILIO_AUTH_TOKEN = os.getenv("TWILIO_AUTH_TOKEN", "")
    # TWILIO_VERIFY_SERVICE_SID = os.getenv("TWILIO_VERIFY_SERVICE_SID", "")

    # MSG91_AUTH_KEY = os.getenv("MSG91_AUTH_KEY", "")
    # MSG91_TEMPLATE_ID = os.getenv("MSG91_TEMPLATE_ID", "")
    # MSG91_SENDER_ID = os.getenv("MSG91_SENDER_ID", "CARNAX")
    # MSG91_OTP_LENGTH = os.getenv("MSG91_OTP_LENGTH", "6")
    # MSG91_OTP_EXPIRY = os.getenv("MSG91_OTP_EXPIRY", "10")

    #   # MSG91 OTP Widget
    # MSG91_WIDGET_ID = os.getenv("MSG91_WIDGET_ID", "366a6167637a343231343531")
    # MSG91_WIDGET_TOKEN = os.getenv("MSG91_WIDGET_TOKEN", "576034TEEAE7rlL6abe0741P1")
    
    # MSG91 — server side (verify access token)
    # MSG91_SERVER_AUTHKEY = os.getenv("MSG91_SERVER_AUTHKEY", "576034AswaZuXucM1h6abe2321P1")


    ADMIN_USERNAME = os.getenv("ADMIN_USERNAME", "admin@careernextacademy.com")
    ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD", "careernext@2026")

    # SMTP
    SMTP_HOST = os.getenv("SMTP_HOST", "smtp.gmail.com")
    SMTP_PORT = int(os.getenv("SMTP_PORT", "465"))
    SMTP_USER = os.getenv("SMTP_USER", "gau879731raj@gmail.com")
    SMTP_PASS = os.getenv("SMTP_PASS", "cwqc wweg zvta sgrp")
    FROM_EMAIL = os.getenv("FROM_EMAIL", os.getenv("SMTP_USER", " gau879731raj@gmail.com"))
    ADMIN_EMAIL = os.getenv("ADMIN_EMAIL", "gau879731raj@gmail.com")

    REG_FEE = 249



